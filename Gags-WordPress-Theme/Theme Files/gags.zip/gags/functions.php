<?php
/**
 * List of files inclusion and functions
 * 
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */

$version = wp_get_theme()->Version;

// Include theme functions
require_once( get_template_directory() . '/functions/theme-functions/theme-widgets.php' ); // Load widgets
require_once( get_template_directory() . '/functions/theme-functions/theme-support.php' ); // Load theme support
require_once( get_template_directory() . '/functions/theme-functions/theme-functions.php' ); // Load custom functions
require_once( get_template_directory() . '/functions/theme-functions/theme-styles.php' ); // Load JavaScript, CSS & comment list layout
require_once( get_template_directory() . '/functions/class-tgm-plugin-activation.php' ); // Load TGM-Plugin-Activation

/**
 * After setup theme
 *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
function gags_theme_init() {
	add_action( 'widgets_init', 'gags_register_sidebars' );
}
add_action( 'after_setup_theme', 'gags_theme_init' );


/**
 * Loads the Options Panel
 * 
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */

if ( file_exists( get_template_directory() . '/functions/theme-functions/theme-options.php' ) ) {
	require_once( get_template_directory() . '/functions/theme-functions/theme-options.php' );
}

// Disable wp admin bar on frontend
add_filter('show_admin_bar', '__return_false');

/**
 * Required & recommended plugins
 * *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
function gags_required_plugins() {
	$plugins = array(
		array(
			'name'			=> 'ZillaShortcodes',
			'version' 		=> '2.0.2',
			'slug'			=> 'zilla-shortcodes',
			'source'		=> get_template_directory() . '/plugins/zilla-shortcodes.zip',
			'external_url'	=> '',
			'required'		=> false,
		),
		array(
			'name'			=> 'Gags Plugin',
			'version' 		=> '1.0.0',
			'slug'			=> 'gags-plugin',
			'source'		=> get_template_directory() . '/plugins/gags-plugin.zip',
			'external_url'	=> '',
			'required'		=> true,
		),
		array(
			'name'			=> 'Video Thumbnails',
			'slug'			=> 'video-thumbnails',
			'required'		=> true,
		),
		array(
			'name'			=> 'Redux Framework',
			'slug'			=> 'redux-framework',
			'required'		=> true,
		),
		array(
			'name'			=> 'WP Page-Navi',
			'slug'			=> 'wp-pagenavi',
			'required'		=> true,
		),
		array(
			'name'			=> 'Yet Another Related Posts Plugin (YARPP)',
			'slug'			=> 'yet-another-related-posts-plugin',
			'required'		=> true,
		),
		array(
			'name'			=> 'WordPress SEO by Yoast',
			'slug'			=> 'wordpress-seo',
			'required'		=> false,
		),
	);

	$string = array(
		'page_title'                      => esc_html__( 'Install Required Plugins', 'gags' ),
		'menu_title'                      => esc_html__( 'Install Plugins', 'gags' ),
		'installing'                      => esc_html__( 'Installing Plugin: %s', 'gags' ),
		'oops'                            => esc_html__( 'Something went wrong with the plugin API.', 'gags' ),
		'notice_can_install_required'     => _n_noop(
			'This theme requires the following plugin: %1$s.',
			'This theme requires the following plugins: %1$s.',
			'gags'
		),
		'notice_can_install_recommended'  => _n_noop(
			'This theme recommends the following plugin: %1$s.',
			'This theme recommends the following plugins: %1$s.',
			'gags'
		),
		'notice_cannot_install'           => _n_noop(
			'Sorry, but you do not have the correct permissions to install the %1$s plugin.',
			'Sorry, but you do not have the correct permissions to install the %1$s plugins.',
			'gags'
		),
		'notice_ask_to_update'            => _n_noop(
			'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
			'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
			'gags'
		),
		'notice_ask_to_update_maybe'      => _n_noop(
			'There is an update available for: %1$s.',
			'There are updates available for the following plugins: %1$s.',
			'gags'
		),
		'notice_cannot_update'            => _n_noop(
			'Sorry, but you do not have the correct permissions to update the %1$s plugin.',
			'Sorry, but you do not have the correct permissions to update the %1$s plugins.',
			'gags'
		),
		'notice_can_activate_required'    => _n_noop(
			'The following required plugin is currently inactive: %1$s.',
			'The following required plugins are currently inactive: %1$s.',
			'gags'
		),
		'notice_can_activate_recommended' => _n_noop(
			'The following recommended plugin is currently inactive: %1$s.',
			'The following recommended plugins are currently inactive: %1$s.',
			'gags'
		),
		'notice_cannot_activate'          => _n_noop(
			'Sorry, but you do not have the correct permissions to activate the %1$s plugin.',
			'Sorry, but you do not have the correct permissions to activate the %1$s plugins.',
			'gags'
		),
		'install_link'                    => _n_noop(
			'Begin installing plugin',
			'Begin installing plugins',
			'gags'
		),
		'update_link'                     => _n_noop(
			'Begin updating plugin',
			'Begin updating plugins',
			'gags'
		),
		'activate_link'                   => _n_noop(
			'Begin activating plugin',
			'Begin activating plugins',
			'gags'
		),
		'return'                          => esc_html__( 'Return to Required Plugins Installer', 'gags' ),
		'dashboard'                       => esc_html__( 'Return to the dashboard', 'gags' ),
		'plugin_activated'                => esc_html__( 'Plugin activated successfully.', 'gags' ),
		'activated_successfully'          => esc_html__( 'The following plugin was activated successfully:', 'gags' ),
		'plugin_already_active'           => esc_html__( 'No action taken. Plugin %1$s was already active.', 'gags' ),
		'plugin_needs_higher_version'     => esc_html__( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'gags' ),
		'complete'                        => esc_html__( 'All plugins installed and activated successfully. %1$s', 'gags' ),
		'dismiss'                         => esc_html__( 'Dismiss this notice', 'gags' ),
		'contact_admin'                   => esc_html__( 'Please contact the administrator of this site for help.', 'gags' )
	);

	$theme_text_domain = 'gags';

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id' => 'gags',
		'default_path' => '',
		'menu' => 'themes.php',
		'parent_slug' => 'themes.php',
		'menu' => 'install-plugins',
		'has_notices' => true,
		'dismissable'  => true,
 		'dismiss_msg'  => '',
		'is_automatic' => true,
		'message' => '',
		'strings' => $string
	);

	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'gags_required_plugins' );