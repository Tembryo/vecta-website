<?php
/**
 * The template for displaying posts in the Standard post format.
 *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
?>

<div class="post-lists">
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'post single-post' ); ?>>
		<h3 class="post-title"><a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>

		<div class="article-footer">
			<?php echo gags_meta(); // display post meta ?>
			<?php echo gags_sharing(); // display post sharing button ?>
		</div>

		<div class="clearfix"></div>

		<?php if ( has_post_thumbnail() ) : ?>
			<div class="thumbnail">
				<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php the_title(); ?>">
					<?php the_post_thumbnail( 'gags-post-thumbnail', array( 'alt' => get_the_title(), 'title' => get_the_title() ) ); ?>
				</a>
			</div>
		<?php endif; ?>

		<div class="entry-content">
			<?php
			the_content();
			
			// Display post pagination
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'gags' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
			) );
			?>
		</div>

		<div class="tags">
			<?php the_tags( esc_html__( 'Tags : ', 'gags' ) .'', '', '' ); ?>
		</div>
	</article>
</div>