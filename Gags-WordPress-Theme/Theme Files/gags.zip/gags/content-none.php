<?php
/**
 * The template for displaying posts in the not found post format.
 *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
	<p><?php esc_html_e( 'The page you\'re looking for is not available. The page may have been deleted or unpublished.', 'gags' ); ?></p>
</article>