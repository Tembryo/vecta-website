<?php
/**
 * Template for displaying Page post type.
 *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
?>
<?php get_header(); ?>

<!-- Start : Main Content -->
<div id="main">
    <div class="container clearfix">
        <div id="maincontent">  
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'hentry post' ); ?>>
                <p><?php esc_html_e( 'The page you\'re looking for is not available. The page may have been deleted or unpublished.', 'gags' ); ?></p>
            </article>
        </div>

    <?php get_sidebar(); ?>
    </div>
</div>
<!-- End : Main Content -->
        
<?php get_footer(); ?>