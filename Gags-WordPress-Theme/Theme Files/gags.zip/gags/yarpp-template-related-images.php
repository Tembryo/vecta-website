<?php 
/**
 * Yarpp Related Images Templates
 *
 * @package WordPress
 * @subpackage Gags
 * @since Gags 1.0.0
 */
?>

<h4 class="widget-title"><?php esc_html_e('Related Gags', 'gags'); ?></h4>
<div class="yarpp-thumbnails-horizontal">
    <?php if (have_posts()):?>
        <ol>
          <?php while (have_posts()) : the_post(); ?>
            <li>
              <div class="thumbnail">
                <a class="yarpp-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                <?php
                if( has_post_thumbnail() ) {
                  the_post_thumbnail('thumbnail');
                } else {
                  $thumb_image = "http://placehold.it/126x126/?text=".esc_html__('No Thumbnail', 'gags');
                  echo '<a href="'.esc_url( get_permalink() ).'" title="'.get_the_title().'" alt="'.get_the_title().'">';
                    echo '<img src="'.$thumb_image.'" alt="'.get_the_title().'" title="'.get_the_title().'">';
                  echo '</a>';
                }
                ?>
                </a>
              </div>
              <a class="yarpp-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo wp_trim_words( get_the_title(), 5, '...' ); ?></a>
            </li>
          <?php endwhile; ?>  
        </ol>
    <?php else: ?>
        <p><?php esc_html_e('No related gag.', 'gags'); ?></p>
    <?php endif; ?>
</div>